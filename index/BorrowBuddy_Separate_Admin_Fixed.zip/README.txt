BorrowBuddy - Separate Student and Administrator Portals

FILES
- index.html: Student portal (no Admin tab/link)
- admin.html: Administrator portal with Approve and Reject controls
- README.txt: Setup notes

HOW TO TEST THE DEMO
1. Extract the ZIP file into a normal folder.
2. Open index.html in one browser, for example Chrome.
3. Create a student profile using a student name and ID.
4. Complete the Digital Logbook for an available item.
5. Submit the borrowing request.
6. In the SAME browser, open admin.html from the same extracted folder.
7. Sign in with the demo password: admin123
8. Open Borrowing Requests. Pending requests have Approve and Reject buttons.
9. Click Approve or Reject. Refresh Requests is available if needed.
10. Return to the student page in the same browser and refresh it.

IMPORTANT
- Do not open the student page in Chrome and the admin page in Edge for this demo.
  Each browser has its own localStorage, so they will not share requests.
- Do not run the pages from inside the ZIP preview. Extract the ZIP first.
- This localStorage prototype shares data only within the same browser profile and
  same website origin. It does not sync between different devices or users.
- The demo password is visible in the HTML source and is NOT secure authentication.
- For a real school system, use Firebase or Supabase with user accounts, database
  security rules, and administrator-only permissions.
